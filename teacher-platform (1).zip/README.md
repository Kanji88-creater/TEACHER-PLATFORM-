# Teacher Platform

A school platform for Zambian teachers, HODs, Deputy Heads and Head teachers.
Teachers prepare documents, send them to the HOD to be checked and stamped, the HOD sends the department's documents to the Deputy Head, and the Head teacher sees overall school performance.

## What you need
- A computer or hosting service running **Node.js 22.13 or newer** (nothing else to install).
- A web address with **HTTPS** (for example behind Caddy or Nginx, or a host that gives HTTPS). Sign-in cookies, the camera and installing the app on phones all need HTTPS.

## Start it
```
cd teacher-platform
cp .env.example .env     # then set the values in your hosting panel or shell
node server.js
```
Open the address. The first person to sign up as **Head Teacher** creates the school and gets a **school code**. Everyone else signs up with that code and is approved by the Head teacher (teachers can also be approved by their HOD).

## Environment settings (see .env.example)
`PORT`, `DATA_DIR` (where the database lives, back it up), `COOKIE_SECURE=1`, `TRUST_PROXY=1` (only behind your own proxy), `DEV_USER`, `DEV_PASS`, optional `DEV_PATH`, optional `STAMP_SECRET`.

## Who can see what (enforced on the server)
| Role | Access |
|---|---|
| Teacher | Own classes, pupils, marks, plans, photos; check results on own documents |
| HOD | Documents submitted by teachers in the own department; department numbers; approves own teachers |
| Deputy Head | Department batches sent by HODs; school numbers |
| Head teacher | School numbers, staff list and approvals, how many documents are checked. No pupil names, photos or document contents |
| Developer | Hidden area only (below) |

## The document flow
1. Teacher submits a test, record of work, individual work plan, lesson plan or class register to the HOD.
2. HOD opens it and approves (a unique stamp is created) or returns it with a comment. A returned document is corrected and sent again as a new version.
3. HOD sends the checked documents (and their own) to the Deputy Head as a batch.
4. Deputy Head approves the batch (each document gets a Deputy Head stamp) or returns it.
5. Anyone can confirm a stamp at `/verify.html` by typing its code. If a document was changed after it was checked, the app warns the teacher.
Reminders appear when a check is overdue (default 7 days, set in Settings).

## The developer area (never linked or shown to users)
Set `DEV_USER` and `DEV_PASS`. The page lives at a secret path printed when the server starts (or the `DEV_PATH` you chose). There you publish schemes of work (typed, CSV, or PDF/Word files) to every teacher. If `DEV_PASS` is empty the area is switched off.

## AI assistant
The assistant gives template drafts by default. For real AI, deploy `ai-proxy-example.js` (a small Cloudflare Worker) with your Anthropic API key and `ACCESS_CODE`, then each teacher enters its address and code in Settings. The key never goes into the app.

## Tests
`node test-api.js` checks roles, privacy rules, stamps and the developer area. `node test-client.js` runs the app's browser code against the real server through the whole checking flow.

## Known limits (please read)
- Not yet tried in real browsers or on phones. Test on one phone and one laptop before the school relies on it.
- There is no email system, so **no "forgot password"** and no email confirmation yet. A forgotten password currently needs the developer to reset it in the database.
- Data is not encrypted at rest. Protect the server, use HTTPS, restrict who can log in to it, and back up `DATA_DIR`.
- A teacher's data syncs as one file; if the same account is edited on two devices at once the newer server copy wins and the older one is saved as a backup on that device.
- Check your school's duties under Zambia's data protection law, especially for pupil photos.
